package com.readforce.enums;

public enum LiteratureRelate {

	;
	
	public static enum type {
		
		NOVEL, FAIRYTALE
		
	}
	
}
