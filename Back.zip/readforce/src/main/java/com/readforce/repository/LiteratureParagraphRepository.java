package com.readforce.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.readforce.dto.LiteratureDto.GetLiteratureParagraph;
import com.readforce.entity.LiteratureParagraph;
import com.readforce.id.LiteratureParagraphId;

@Repository
public interface LiteratureParagraphRepository extends JpaRepository<LiteratureParagraph, LiteratureParagraphId>{

	@Query("SELECT lp FROM LiteratureParagraph lp WHERE EXISTS(SELECT l FROM Literature l WHERE type = :type)")
	List<GetLiteratureParagraph> getLiteratureParagraphListByTypeOrderByAsc(@Param("type") String type);

}
