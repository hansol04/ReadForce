package com.readforce.enums;

public enum Name {
	ACCESS_TOKEN, TEMPORAL_TOKEN, REFRESH_TOKEN, NICK_NAME
}
