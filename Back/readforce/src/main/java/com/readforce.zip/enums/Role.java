package com.readforce.enums;

public enum Role {
	ADMIN, USER
}
