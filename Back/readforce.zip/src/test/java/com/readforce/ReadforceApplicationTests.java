package com.readforce;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReadforceApplicationTests {

	@Test
	void contextLoads() {
	}

}
