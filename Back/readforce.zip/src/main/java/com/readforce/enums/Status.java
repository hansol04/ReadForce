package com.readforce.enums;

public enum Status {
	ACTIVE, PENDING_DELETION
}
